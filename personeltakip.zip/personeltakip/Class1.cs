﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace personeltakip
{
    internal class Class1
    {
        public static string database_path = System.IO.File.ReadAllText("C:\\Program Files (x86)\\personeltakip\\application_database_path.txt");
    }
}
