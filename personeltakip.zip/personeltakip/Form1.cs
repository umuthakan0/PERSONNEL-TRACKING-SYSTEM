﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.VisualBasic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace personeltakip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // public static string veriyolu = System.IO.File.ReadAllText(@"C:\\Program Files\\personeltakipsistemi\\personeltaksisveriyolu.txt");
        // public static string veriyolu2 = System.IO.File.ReadAllText(@"C:\\Program Files\\personeltakipsistemi\\pertaksisveriyolu2.txt");
        SqlConnection baglan = new SqlConnection(Class1.database_path);
        void listelee()
        {
            daset.Tables.Clear();
            SqlDataAdapter sec = new SqlDataAdapter("select * from tbl_PerBilgi ", baglan);
            sec.Fill(daset, "tbl_PerBilgi");
            dataGridView1.DataSource = daset.Tables["tbl_PerBilgi"];
        }
        void duzenle()
        {
            string ilkhrf;
            ilkhrf = txtisim.Text.Substring(0, 1).ToUpper();
            txtisim.Text = ilkhrf + txtisim.Text.Substring(1).ToLower();
            ilkhrf = txtsoyad.Text.Substring(0, 1).ToUpper();
            txtsoyad.Text = ilkhrf + txtsoyad.Text.Substring(1).ToLower();
            ilkhrf = txtmeslek.Text.Substring(0, 1).ToUpper();
            txtmeslek.Text = ilkhrf + txtmeslek.Text.Substring(1).ToLower();
            ilkhrf = cmbsehir.Text.Substring(0, 1).ToUpper();
            cmbsehir.Text = ilkhrf + cmbsehir.Text.Substring(1).ToLower();
        }
        void temizle()
        {
            txtisim.Text = "";
            txtmaas.Text = "";
            txtmeslek.Text = "";
            txtsoyad.Text = "";
            cmbsehir.Text = "";
            rbnbekar.Checked = false;
            rbnevli.Checked = false;
            txtisim.Focus();
        }
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //bu kısımda ınputboxdan gelen ıd degerıyle silme işlemi yapıyoruz ...
            baglan.Open();
            string secim = Interaction.InputBox("silmek istediğiniz id kim ?", "kişi silme", "", 50, 50);
            SqlCommand sil =
                new SqlCommand("delete  from tbl_PerBilgi where PerId = @pid", baglan);
            sil.Parameters.AddWithValue("@pid", secim);
            sil.ExecuteNonQuery();
            MessageBox.Show("kişi başarıyla silindi...", "UYARI");
            listelee();
            baglan.Close();
            
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtisim.Text == "" || txtmaas.Text == "" || txtmeslek.Text == "" || txtsoyad.Text == "" || cmbsehir.Text == "" || txtfoto.Text=="")
                MessageBox.Show("BOŞTA KALAN VERİLER MEVCUD LÜTFEN BU KISIMLARI DOLDURUN !", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                duzenle();
                if (rbnbekar.Checked)
                {
                    medenihal = 0;
                }
                else if (rbnevli.Checked)
                {
                    medenihal = 1;
                }
                baglan.Open();
                SqlCommand update =
                    new SqlCommand("Update tbl_PerBilgi Set PerAd=@u1,PerSoyad=@u2,PerSehir=@u3,PerMedenihal=@u4,PerMeslek=@u5,PerMaas=@u6,PerFotograf=@p1 where PerId=@u7", baglan);
                update.Parameters.AddWithValue("@u1", txtisim.Text);
                update.Parameters.AddWithValue("@u2", txtsoyad.Text);
                update.Parameters.AddWithValue("@u3", cmbsehir.Text);
                update.Parameters.AddWithValue("@u4", medenihal);
                update.Parameters.AddWithValue("@u5", txtmeslek.Text);
                update.Parameters.AddWithValue("@u6", txtmaas.Text);
                update.Parameters.AddWithValue("@u7", txtperid.Text);
                update.Parameters.AddWithValue("@p1", yol);
                update.ExecuteNonQuery();
                listelee();
                MessageBox.Show("GÜNCELLEME BAŞARILI..", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                baglan.Close();
                yol = "";
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
        }
        int medenihal;
        private void btn_Click(object sender, EventArgs e)
        {
            if (txtisim.Text == "" || txtmaas.Text == "" || txtmeslek.Text == "" || txtsoyad.Text == "" || cmbsehir.Text == "")
                MessageBox.Show("BOŞTA KALAN VERİLER MEVCUD LÜTFEN BU KISIMLARI DOLDURUN !", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                if (yol == "")
                {
                    DialogResult dugme = MessageBox.Show("Personelin resmi yok devam etmek istiyor musunuz?", "UYARI", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dugme == DialogResult.Yes)
                    {
                        duzenle();
                        if (rbnbekar.Checked)
                        {
                            medenihal = 0;
                        }
                        else if (rbnevli.Checked)
                        {
                            medenihal = 1;
                        }
                        baglan.Open();
                        SqlCommand ekle =
                            new SqlCommand("insert into tbl_PerBilgi (PerAd,PerSoyad,PerSehir,PerMedenihal,PerMeslek,PerMaas,PerFotograf) values (@pad,@psoyad,@psehir,@pmedenihal,@pmeslek,@pmaas,@fotograf)", baglan);
                        ekle.Parameters.AddWithValue("@pad", txtisim.Text);
                        ekle.Parameters.AddWithValue("@psoyad", txtsoyad.Text.ToUpper());
                        ekle.Parameters.AddWithValue("@psehir", cmbsehir.Text);
                        ekle.Parameters.AddWithValue("@pmedenihal", medenihal);
                        ekle.Parameters.AddWithValue("@pmeslek", txtmeslek.Text.ToUpper());
                        ekle.Parameters.AddWithValue("@pmaas", txtmaas.Text);
                        ekle.Parameters.AddWithValue("@fotograf", yol);
                        ekle.ExecuteNonQuery();
                        MessageBox.Show("kişi başarıyla eklendi...", "UYARI");
                        listelee();
                        temizle();
                        baglan.Close();
                        yol = "";
                    }
                }
                else
                {
                    duzenle();
                    if (rbnbekar.Checked)
                    {
                        medenihal = 0;
                    }
                    else if (rbnevli.Checked)
                    {
                        medenihal = 1;
                    }
                    baglan.Open();
                    SqlCommand ekle =
                        new SqlCommand("insert into tbl_PerBilgi (PerAd,PerSoyad,PerSehir,PerMedenihal,PerMeslek,PerMaas,PerFotograf) values (@pad,@psoyad,@psehir,@pmedenihal,@pmeslek,@pmaas,@fotograf)", baglan);
                    ekle.Parameters.AddWithValue("@pad", txtisim.Text);
                    ekle.Parameters.AddWithValue("@psoyad", txtsoyad.Text.ToUpper());
                    ekle.Parameters.AddWithValue("@psehir", cmbsehir.Text);
                    ekle.Parameters.AddWithValue("@pmedenihal", medenihal);
                    ekle.Parameters.AddWithValue("@pmeslek", txtmeslek.Text.ToUpper());
                    ekle.Parameters.AddWithValue("@pmaas", txtmaas.Text);
                    ekle.Parameters.AddWithValue("@fotograf", yol);
                    ekle.ExecuteNonQuery();
                    MessageBox.Show("kişi başarıyla eklendi...", "UYARI");
                    listelee();
                    temizle();
                    baglan.Close();
                    yol = "";
                }
            }
        }
        DataSet daset = new DataSet();
        private void btnlistele_Click(object sender, EventArgs e)
        {
            //bu kısımda datagriedviewe verileri lşstreliyoruz...
            //daset.tables bu kod verileri tekrar tekrar datagried viewde gosteriilmesin kuyruga eklenmesin diye...
            daset.Tables.Clear();
            baglan.Open();
            SqlDataAdapter sec = new SqlDataAdapter("select * from tbl_PerBilgi ", baglan);
            // sec.fill ile sec gelen verisini tablo halıne getırıyoruz...
            sec.Fill(daset, "tbl_PerBilgi");
            dataGridView1.DataSource = daset.Tables["tbl_PerBilgi"];
            baglan.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            yol = "";
            cmbsehir.Items.Clear();
            baglan.Open();
            SqlCommand sehir =
                new SqlCommand("select sehirler from tbl_sehirler",baglan);
            SqlDataReader ekle = sehir.ExecuteReader();
            cmbsehir.Items.Add("ŞEHİR SEÇ");
            while(ekle.Read())
            {
                cmbsehir.Items.Add(ekle[0].ToString());
                cmbsehir.SelectedIndex = 0;
            }
            ekle.Close();
            baglan.Close();
            txtperid.Enabled = false;
            listelee();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnraporla_Click(object sender, EventArgs e)
        {
            raporlama rpr = new raporlama();
            rpr.Show();
        }

        private void Form1_Click(object sender, EventArgs e)
        {

        }
        public static int secilen, durum;
        public static string sehir, isim, soyad, meslek, id, maas;
        public static string yol;
        private void button2_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Lütfen bir fotoğraf seçin.";
            openFileDialog1.Filter = "Png Dosyası(*.png)|*.png |Jpg Dosyası (*.jpg)|*.jpg";
            openFileDialog1.ShowDialog();
            yol = openFileDialog1.FileName;
            txtfoto.Text = yol;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            secilen = dataGridView1.SelectedCells[0].RowIndex;
            id = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            isim = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            soyad = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            sehir = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            durum = Convert.ToInt32(dataGridView1.Rows[secilen].Cells[4].Value);
            meslek = dataGridView1.Rows[secilen].Cells[5].Value.ToString();
            maas = dataGridView1.Rows[secilen].Cells[6].Value.ToString();
            txtperid.Text = id;
            txtisim.Text = isim;
            txtsoyad.Text = soyad;
            cmbsehir.Text = sehir;
            txtmeslek.Text = meslek;
            txtmaas.Text = maas;
            if (durum == 1)
            {
                rbnevli.Checked = true;
            }
            else if (durum == 0)
            {
                rbnbekar.Checked = true;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (txtisim.Text == "" || txtmaas.Text == "" || txtmeslek.Text == "" || txtsoyad.Text == "" || cmbsehir.Text == "")
                MessageBox.Show("BOŞTA KALAN VERİLER MEVCUD LÜTFEN BU KISIMLARI DOLDURUN !", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                kisigoruntule frm4 = new kisigoruntule();
                frm4.Show();
            }
        }
    }
}
