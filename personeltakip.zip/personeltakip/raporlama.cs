﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace personeltakip
{
    public partial class raporlama : Form
    {
        public raporlama()
        {
            InitializeComponent();
        }

        private void raporlama_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'personellerDataSet.tbl_PerBilgi' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.tbl_PerBilgiTableAdapter.Fill(this.personellerDataSet.tbl_PerBilgi);

            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
        }
    }
}
