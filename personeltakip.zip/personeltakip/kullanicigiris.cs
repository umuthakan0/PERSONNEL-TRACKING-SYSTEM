﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace personeltakip
{
    public partial class kullanicigiris : Form
    {
        public kullanicigiris()
        {
            InitializeComponent();
        }
        SqlConnection baglan =
            new SqlConnection(Class1.database_path);
        private void label2_Click(object sender, EventArgs e)
        {

        }
        int g_hak=5;
        private void button1_Click(object sender, EventArgs e)
        {
            baglan.Open();
            SqlCommand dogrula =
                new SqlCommand("select * from tbl_adminler where PerAd = @u1 and PerSifre = @u2", baglan);
            dogrula.Parameters.AddWithValue("@u1", textBox1.Text);
            dogrula.Parameters.AddWithValue("@u2", textBox2.Text);
            SqlDataReader dr = dogrula.ExecuteReader();
            if (dr.Read())
            {
                Form1 frm = new Form1();
                frm.Show();
                this.Hide();
            }
            else
            {
                g_hak--;
                if (g_hak == 0)
                {
                    groupBox1.Enabled = false;
                }
                DialogResult dugme = MessageBox.Show("HATALI KULLANICIADI_ŞİFRE GİRDİNİZ!!!", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            dr.Close();
            baglan.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sifremiunuttuum frm3 = new sifremiunuttuum();
            frm3.ShowDialog();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            adminmisinkontrolet adm =
                new adminmisinkontrolet();
            adm.Show();
        }
    }
}
