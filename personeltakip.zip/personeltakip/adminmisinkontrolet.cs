﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace personeltakip
{
    public partial class adminmisinkontrolet : Form
    {
        public adminmisinkontrolet()
        {
            InitializeComponent();
        }
        SqlConnection baglan =
            new SqlConnection(Class1.database_path);
        private void button3_Click(object sender, EventArgs e)
        {
            baglan.Open();
            SqlCommand bak =
                new SqlCommand("select * from tbl_superadminler where kullaniciad=@d1 and sifre=@d2",baglan);
            bak.Parameters.AddWithValue("@d1", textBox1.Text);
            bak.Parameters.AddWithValue("@d2", textBox2.Text);
            SqlDataReader dr = bak.ExecuteReader();
            if (dr.Read())
            {
                ADMİNEKLE admin = new ADMİNEKLE();
                admin.Show();
                this.Hide();
            }
            else
            {
                DialogResult dugme = MessageBox.Show("superadmin kullanıcıadı veya şifre hatalı!", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            dr.Close();
            baglan.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void adminmisinkontrolet_Load(object sender, EventArgs e)
        {

        }
    }
}
