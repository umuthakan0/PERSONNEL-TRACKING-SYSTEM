﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace personeltakip
{
    public partial class sifremiunuttuum : Form
    {
        public sifremiunuttuum()
        {
            InitializeComponent();
        }
        SqlConnection baglan = new SqlConnection(Class1.database_path);
        private void button1_Click(object sender, EventArgs e)
        {
            baglan.Open();
            SqlCommand look =
                new SqlCommand("select * from tbl_adminler where PerAd = @u1 and PerEmail = @u2",baglan);
            look.Parameters.AddWithValue("@u1",textBox1.Text);
            look.Parameters.AddWithValue("@u2",textBox2.Text);
            SqlDataReader lk = look.ExecuteReader();
            if (lk.Read())
            {
                MessageBox.Show("LÜTFEN ŞİFRENİZİ KİMSEYLE PAYLAŞMAYINIZ " + lk[2].ToString(), "ŞİFRE HATIRLATILDI");
            }
            else
            {
                DialogResult dugme = MessageBox.Show("HATALI KULLANICIADII_EMAİL GİRDİNİZ!!!", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            lk.Close();
            baglan.Close();
        }

        private void sifremiunuttuum_Load(object sender, EventArgs e)
        {
            sifremiunuttuum frm3 = new sifremiunuttuum();
            frm3.BackColor = Color.Blue;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
