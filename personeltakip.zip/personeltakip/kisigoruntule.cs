﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace personeltakip
{
    public partial class kisigoruntule : Form
    {
        public kisigoruntule()
        {
            InitializeComponent();
        }
        SqlConnection baglan =
           new SqlConnection(Class1.database_path);
        string kayıpfoto = "C:\\Program Files\\personeltakip\\download.png";
        private void kisigoruntule_Load(object sender, EventArgs e)
        {
            txtperid.Enabled = false;
            baglan.Open();
            txtisim.Text = Form1.isim;
            txtsoyad.Text = Form1.soyad;
            txtmaas.Text = Form1.maas;
            txtperid.Text = Form1.id;
            cmbsehir.Text = Form1.sehir;
            txtmeslek.Text = Form1.meslek;
            if (Form1.durum == 1)
            {
                rbnevli.Checked = true;
            }
            else if (Form1.durum == 0)
            {
                rbnbekar.Checked = true;
            }
            SqlCommand ft =
                new SqlCommand("select PerFotograf from tbl_PerBilgi where PerId=@k1",baglan);
            ft.Parameters.AddWithValue("@k1",txtperid.Text);
            SqlDataReader dr = ft.ExecuteReader();
            if(dr.Read())
            {
                if (dr[0].ToString() != "")
                    pictureBox1.ImageLocation = dr[0].ToString();
                else
                    pictureBox1.ImageLocation = kayıpfoto;
            }
            dr.Close();
            baglan.Close();
        }
    }
}
