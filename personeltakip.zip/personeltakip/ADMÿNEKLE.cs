﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Reporting.Map.WebForms.BingMaps;
using Microsoft.VisualBasic.Devices;

namespace personeltakip
{
    public partial class ADMİNEKLE : Form
    {
        public ADMİNEKLE()
        {
            InitializeComponent();
        }
        SqlConnection baglan =
          new SqlConnection(Class1.database_path);
        private void button1_Click(object sender, EventArgs e)
        {
            baglan.Open();
            SqlCommand ekle =
                new SqlCommand("insert into tbl_adminler (PerAd,PerSifre,PerEmail) values(@d1,@d2,@d3)",baglan);
            ekle.Parameters.AddWithValue("@d1", textBox1.Text);
            ekle.Parameters.AddWithValue("@d2", textBox2.Text);
            ekle.Parameters.AddWithValue("@d3", textBox3.Text);
            ekle.ExecuteNonQuery();
            baglan.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            baglan.Open();
            SqlCommand ekle =
                new SqlCommand("insert into tbl_superadminler (kullaniciad,sifre) values(@d1,@d2)", baglan);
            ekle.Parameters.AddWithValue("@d1", textBox1.Text);
            ekle.Parameters.AddWithValue("@d2", textBox2.Text);
            ekle.ExecuteNonQuery();
            baglan.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ADMİNEKLE_Load(object sender, EventArgs e)
        {

        }
    }
}
